package com.example.mpa;

public class upload {

    private String mImageuri;

    public upload() {
    }

    public upload (String imageuri) {

        mImageuri = imageuri;
    }


    public String getmImageuri() {
        return mImageuri;
    }

    public void setmImageuri(String mImageuri) {
        this.mImageuri = mImageuri;
    }
}
