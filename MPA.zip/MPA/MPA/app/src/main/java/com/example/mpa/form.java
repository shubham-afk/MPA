package com.example.mpa;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class form extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    ImageView mImageView;
    private Button mback1;
    Uri mImageUri;
    StorageReference mStorageReference;
    EditText txtname, txtbg , txtphone , adhno;
    Button btnupload,mbtnchoose;
    DatabaseReference ref;
    Users users;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        txtname=(EditText)findViewById(R.id.txtname);
        mback1 = findViewById(R.id.back);
        txtbg=(EditText)findViewById(R.id.txtbg);
        txtphone=(EditText)findViewById(R.id.txtphone);
        adhno=(EditText)findViewById(R.id.adhno);
        btnupload=(Button)findViewById(R.id.btnupload);
        mbtnchoose=findViewById(R.id.btnchoose);
        mImageView=(ImageView)findViewById(R.id.imgv);
        mStorageReference = FirebaseStorage.getInstance().getReference("Images");
        ref = FirebaseDatabase.getInstance().getReference().child("Users").child("USER PERSONAL DATA");
        users = new Users();

        mbtnchoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenImagechooser();
            }
        });

        mback1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity3();
            }
        });

        btnupload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Long phn = Long.parseLong(txtphone.getText().toString().trim());
//                int aad =  Integer.parseInt(adhno.getText().toString().trim());



                users.setName(txtname.getText().toString().trim());
                users.setBg(txtbg.getText().toString().trim());
//                users.setMn(phn);
//                users.setAn(aad);
                users.setMn(txtphone.getText().toString().trim());
                users.setAn(adhno.getText().toString().trim());

                ref.push().push().setValue(users);
                Toast.makeText(form.this, "data is in",Toast.LENGTH_LONG).show();

                UploadFile();
            }
        });
    }

    private void OpenImagechooser(){
        Intent intent =new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,PICK_IMAGE_REQUEST);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == PICK_IMAGE_REQUEST || resultCode == RESULT_OK
        || data !=null || data.getData()!=null)
        {
            mImageUri = data.getData();

            Picasso.with(this).load(mImageUri).into(mImageView);
        }
    }


    private String getFileExt(Uri uri){
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private void UploadFile() {
        if(mImageUri!= null) {
            StorageReference filereference = mStorageReference.child(System.currentTimeMillis()
            +"."+getFileExt(mImageUri));

            filereference.putFile(mImageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                            Toast.makeText(form.this,"Upload Successfull",Toast.LENGTH_LONG).show();
                            String uploadId = ref.push().getKey();
                            ref.child(uploadId);


                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(form.this,e.getMessage(),Toast.LENGTH_LONG).show();
                        }
                    });


        }else {
            Toast.makeText(form.this,"No File Selected",Toast.LENGTH_SHORT).show();
        }
    }


    public void openactivity3() {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }



}
