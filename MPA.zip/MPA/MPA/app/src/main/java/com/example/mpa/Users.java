package com.example.mpa;

public class Users {

    private String Name;
    private String bog;
    private String mon;
    private String aon;

    public Users() {
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getBg() {
        return bog;
    }

    public void setBg(String bg) {
        bog = bg;
    }

    public String getMn() {
        return mon;
    }

    public void setMn(String mn) {
        mon = mn;
    }

    public String getAn() {
        return aon;
    }

    public void setAn(String an) {
        aon = an;
    }
}

